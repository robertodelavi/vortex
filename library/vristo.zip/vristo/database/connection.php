<?php 
    // require_once '../configs.php';
    // require_once 'database.class.php';

    // $db = new MySQLDB(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    // $db->connect(); 

    // Connection example
    // $result = $db->query('SELECT * FROM usuario');
    // while ($row = $result->fetch()) {
    //     echo "<p>Notes ==> {$row['nome']}</p>";
    // }    
    // $db->disconnect();
?>