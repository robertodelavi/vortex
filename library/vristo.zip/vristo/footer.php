<p class="dark:text-white-dark text-center ltr:sm:text-left rtl:sm:text-right pt-6">© <span id="footer-year">2022</span>. Vristo All rights reserved.</p>
