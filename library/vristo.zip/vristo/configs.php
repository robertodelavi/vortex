<?php 
    // Rota base do projeto
    define('BASE_URL', 'http://localhost/vortex'); 
    define('BASE_THEME_URL', 'http://localhost/vortex/library/vristo'); 

    // Conexão Banco de dados
    // define('DB_HOST', 'localhost');
    // define('DB_USER', 'root');
    // define('DB_PASS', '');
    // define('DB_NAME', 'imob__autenticacao');    
?>